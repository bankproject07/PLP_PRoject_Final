SELECT * FROM ACCOUNT_MASTER;

SELECT * FROM payee_table;

insert into PAYEE_TABLE values(100,123456,12345,'ABC');


select * from service_tracker;
select * from USER_TABLE;
insert into USER_TABLE VALUES(12345,1789542,'abcd','sd','789','L');
select * from ACCOUNT_MASTER;

create table Account_Master
(Account_ID NUMBER(10) primary key,
Customer_ID number(10),
Account_Type VARCHAR2(25),
Account_Balance NUMBER(10,2),
Open_Date DATE,
FOREIGN KEY(Customer_ID) REFERENCES customer(Customer_ID));

insert into ACCOUNT_MASTER values(accid_seq.nextVal,)


create table Transaction
(
Transaction_ID NUMBER primary key ,
Tran_description VARCHAR2(100),
DateofTransaction DATE ,
TransactionType VARCHAR2(1),
TranAmount NUMBER(15) ,
Account_ID NUMBER(10),
FOREIGN KEY(Account_ID) REFERENCES Account_Master(Account_ID)
);
create sequence tranID_seq start with 100200 increment by 1 nocache;


insert into TRANSACTION values(tranID_seq.nextVal,'pos','02-oct-2011','k',400,1210212);
select * from SERVICE_TRACKER;

delete TRANSACTION;

select * FROM  transaction WHERE (Dateoftransaction >= '30-jun-2013') AND (Dateoftransaction <= '15-jul-2013');

select * FROM  transaction WHERE (Dateoftransaction = '02-oct-2011');

commit

SELECT * FROM CUSTOMER;

delete from fund_transfer;

select * from fund_transfer;