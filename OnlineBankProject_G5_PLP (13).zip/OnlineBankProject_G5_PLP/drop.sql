drop table Customer1;

drop table Account_master;

drop table RequestTable;

drop table User_Table;

drop table Transaction;

drop table Payee_Table;

drop table Service_Tracker;

drop table Fund_Transfer;

