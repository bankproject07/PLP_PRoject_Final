package com.cg.obs.controller;


import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;







import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;







import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.service.IUserService;



@Controller
public class BankingApplicationController {

	
	@Autowired
	IUserService userService;
	
	public BankingApplicationController() {
		
	}

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public BankingApplicationController(IUserService userService) {
		super();
		this.userService = userService;
	}
	
	
	@RequestMapping("Login")
	public String getLoginPage(@RequestParam("username") int userId,@RequestParam("password") String password,Model model,HttpSession session){
		
		System.out.println(userId+" "+password);
		Users user=userService.getUser(userId);
		System.out.println(user);
		if(user!=null)
		{
			
			
		if(password.equalsIgnoreCase(user.getLoginPassword()))
		{
			System.out.println("user login success");
		      //model.addAttribute("accountno", user.getAccountId());
		session.setAttribute("accountno", user.getAccountId());
		session.setAttribute("userid", userId);
			return "index";
		}
		
		
	}
		model.addAttribute("errMsg", "Login error");
			return "pages/ErrorPage";
			
		
	
	}
	
	@RequestMapping("GetMiniTransactions")
	public String getMiniTransactionPage(Model model,HttpSession session){
		
		System.out.println(session.getAttribute("accountno"));
		Long accountno=(Long)session.getAttribute("accountno");
		//System.out.println(accid);
		//Long accountno=Long.parseLong(accid);
		List<Transactions> miniTransList=userService.getMiniTransactions(accountno);
		System.out.println(miniTransList);
		model.addAttribute("miniTrasactionList",miniTransList);
		
		return "pages/MiniTransactions";
	}
	
	@RequestMapping("GetDetailedTransactions")
	public String getDetailedTransactionsPage(@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate,Model model,HttpSession session) {
		
		System.out.println(session.getAttribute("accountno"));
		Long accountno=(Long)session.getAttribute("accountno");
		List<Transactions> detailedTransactionList=userService.getDetailedTransactions(accountno, fromDate, toDate);
		model.addAttribute("detailedTransactionList",detailedTransactionList);
		return "pages/DetailedTransactions";
	}

	
	@RequestMapping("UpdateProfile")
	 public String getUpdatePage(Model model,HttpSession session)
	 {
		 
  System.out.println("hello");
  Long accountno=(Long)session.getAttribute("accountno");
 int customerId=userService.getCustomerId(accountno);
	System.out.println(customerId);
	Customer customer2;
  
  try{
		System.out.println("in try");
		
		customer2=new Customer();
		customer2=userService.getCustomer(customerId);
		
		customer2.getCustomer_ID();
		customer2.getCustomer_Name();
		customer2.getEmail();
		customer2.getMobileNo();
		customer2.getAddress();
		customer2.getPancard();
		System.out.println("c2"+customer2);
		model.addAttribute("customer2", customer2);
		
		return "pages/UpdateProfile";
	/*	System.out.println("in update sucess"+customer2);
		userService.updateCustomerDetails(customer2);
		System.out.println("update sucess");
		return "pages/UpdateProfileSuccess";*/
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg",
					"Wrong format for mobile no");
			return "pages/UpdateProfile";
		}
	 }
	 

	 @RequestMapping(value="ProcessUpdate" , method=RequestMethod.POST)
	  public String ProcessupdatePageFrom(@ModelAttribute("customer2")
	  @Valid Customer customer,
	 BindingResult result,Model model,HttpSession session)
	  {
		 
		 System.out.println("in processs yupdate");
		 if (result.hasErrors() == true) 
		 {
				
				model.addAttribute("customer",customer);

				
			
				return "pages/UpdateProfile";
	  }

		 try 
		 {
		
				
			    System.out.println(customer);
			    userService.updateCustomerDetails(customer);
				 model.addAttribute("message", "customer details updated  Successfully");
					
			    return "pages/UpdateProfileSuccess";
		} 
		 catch (Exception e)
		 {
			model.addAttribute("errMsg", "Could Not Update customer Details. Reason:" + e.getMessage());
			return "pages/ErrorPage";
		}
			
	
	 }
		
		
		
	/*@RequestMapping("trackRequest")
	public String getViewCustomerPage()
	{
		return "ShowServiceTrack" ;
	}*/
	
	@RequestMapping(value="processGetServiceTrack" , method=RequestMethod.POST)
	public String processViewDetails(@RequestParam("requestId") int id , Model model)
	{
		ServiceTracker tracker = null ;
		try
		{
			tracker = userService.getRequestedServiceList(id) ;
			System.out.println(tracker);
		}
		catch(Exception e)
		{
			
			model.addAttribute("errMsg", "Something went wrong while service tracking reason " + e.getMessage()) ;
			return "ErrorPage" ;
		}
		model.addAttribute("tracker", tracker) ;
		return "ShowServiceTrack" ;
	}
	/*@RequestMapping("chqBookRqstSuccess")
	public String getAddCustomerPage(Model model)
	{
		model.addAttribute("services", new ServiceTracker()) ;
		
		return "ChqBookRqstSuccess";
		
	}
	*/
	@RequestMapping(value="ChangePassword", method=RequestMethod.POST)
	public String changePassword(@RequestParam("oldPass")String oldPass,
			@RequestParam("newPass")String newPass ,
			@RequestParam("confirmPass")String confirmPass,
			HttpSession session ,
			Model model)
	{
	System.out.println("in controller");
	
	int id = (int) session.getAttribute("userid");
	Users users = null;
	try
	{
		users = userService.getUser(id);
		System.out.println("in try");
		if(oldPass.equalsIgnoreCase(users.getLoginPassword()))
		{
			System.out.println("valid password");
		if (newPass.equals(confirmPass)) {
			System.out.println("equals password");
			users.setLoginPassword(confirmPass);
			
			userService.changePassword(users);

			System.out.println("confirm");
			return "pages/ChangePasswordSuccess";

		} else {
			return "pages/ErrorPage";
		}
		}
		else
		{
			return "pages/ErrorPage";
		}
		}
	catch(Exception e)
	{
		e.printStackTrace();
		model.addAttribute("errMsg", "Something went wrong while adding customer reason " + e.getMessage()) ;
		return "ErrorPage" ;
	}
}
	
	@RequestMapping("processChqBookRqstExist")
	public String processAddChqBookRqst(Model model,HttpSession serviceIdsession)
	{
		ServiceTracker tracker = null;
		int id=-1;
		int serviceid=-1;
		
		try{
		System.out.println("start");
		
		//String accno=(String)session.getAttribute("accountno");
		//Long accountno=Long.parseLong(accno);
		Long accountno=(Long)serviceIdsession.getAttribute("accountno");
		System.out.println(accountno);
		 serviceid=userService.isCheckBookRequestExist(accountno);
		System.out.println("in ctr"+serviceid);
		if(serviceid==0)
		{
			
			
			serviceIdsession.setAttribute("serviceId", serviceid);

			
		// String desc=(String)session.getAttribute("Send request");
		String desc = "Cheque Book request";
		System.out.println(desc);
		// long accId=(long)session.getAttribute("123");
					// Date risedDate=(Date)session.getAttribute("2017-09-09");

		// String myDate="09/09/2017";
	
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);

		System.out.println(date);
		// String status=(String)session.getAttribute("Processing");        
		String status = "Open";

		tracker = new ServiceTracker();

		tracker.setService_Description(desc);
		tracker.setAccount_ID(accountno);
		tracker.setService_Raised_Date(date);
		tracker.setService_Status(status);

		System.out.println(tracker);

		 id = userService.requestService(tracker);

		System.out.println("in ctrl id:" + id);

		model.addAttribute("message", "Request already  exists with id: "+ id) ;
		return "pages/SuccessPage" ;
		
		
		}
		}catch(Exception e)
			{
				e.printStackTrace();
				model.addAttribute("errMsg", "Something went wrong while requesting service, reason " + e.getMessage()) ;
				return "pages/ErrorPage" ;
			}
			
			model.addAttribute("message", "Request added successfully with "+ serviceid) ;
			return "pages/SuccessPage" ;
	}
	

	

	@RequestMapping("ProcessUpdateCustomerForm")
	public String processUpdate(@ModelAttribute("customer") @Valid Customer customer, BindingResult result,Model model)
	{
		
		try 
		{
			userService.updateCustomerDetails(customer);
		}
		catch (Exception e)
		{
			
			model.addAttribute("errMsg", "Could Not Update customer details Reason " + e.getMessage()) ;
			return "ErrorPage";
		
		}
		
		model.addAttribute("customer", customer);
		model.addAttribute("message", "customer Updated Successfully");
		

		return "UpdateProfileSuccess";
	}
	
	@RequestMapping("FundTransfer")
	public String getPayeeListPage(Model model,HttpSession session)
	{
		Long accountno=(Long)session.getAttribute("accountno");
		List<Payee> payeeList=userService.getPayee(accountno);
		model.addAttribute("payeeList",payeeList);
		return "pages/FundTransfer";
	}
	
	@RequestMapping("TransactionDetails")
	public String getTransactionDetailsPage(@RequestParam("selectpayee") String payee ,HttpSession session)
	{
		//Long payeeaccount=Long.parseLong(payee);
		session.setAttribute("payeeAccountNo", payee);
		return "pages/FTPay";
	}
	
	
	@RequestMapping(value="AddPayee", method=RequestMethod.POST)
	public String processAddPayee(@RequestParam("txtAccountNo")long payeeAccountNo,@RequestParam("txtNickName")String nickName,HttpSession session,Model model)
	{
		Long accountno = (Long) session.getAttribute("accountno");

		System.out.println("in add payee");
		System.out.println(userService.isPayeeAccountExists(payeeAccountNo));
		try {
			if (userService.isPayeeAccountExists(payeeAccountNo)) {

				int randomInt = (int) (10.0 * Math.random());

				// request.setAttribute("urncode",randomInt);
			
				session.setAttribute("urncode", randomInt);
				model.addAttribute("urncode", randomInt);
				System.out.println("urncode" + randomInt);
				session.setAttribute("payeeAccountNo", payeeAccountNo);
				session.setAttribute("nickname", nickName);
				System.out.println("random no"+randomInt);
				return "pages/PayeeSuccess";
				
			}
			else
			{
				model.addAttribute("errMsg",
						"Payee Account number does not exist");
				return "pages/FTAddPayee";
			}
		} 
		catch (Exception e) {
			model.addAttribute("errMsg",
					"Payee Account number does not exist");
			return "pages/FTAddPayee";
		}	
		
		//return "pages/PayeeSuccess";
	}
	
	
	@RequestMapping(value="ValidateURN", method=RequestMethod.POST)
	public String processValidateUrnPage(@RequestParam("txtURN")int urncode,Model model,HttpSession session)
	{
		
		System.out.println("validate urn");
		int urnconfirmcode=(int)session.getAttribute("urncode");
		Payee payee=null;
		System.out.println(urncode+"="+urnconfirmcode);
		if(urnconfirmcode==urncode)
		{
			try{
			System.out.println("in try");	
			Long accountno = (Long) session.getAttribute("accountno");
			Long payeeAccountNo=(Long)session.getAttribute("payeeAccountNo");
			String nickname=(String)session.getAttribute("nickname");
			
			System.out.println(accountno+payeeAccountNo+nickname);
			payee=new Payee();
			payee.setAccountno(accountno);
			payee.setPayeeAccountNo(payeeAccountNo);
			payee.setNickName(nickname);
			System.out.println(payee);
			userService.insertPayee(payee);
			
			return "pages/URNSuccess";
			}
			catch(Exception e)
			{
				model.addAttribute("errMsg",
						"Error Occured while adding payee"+e.getMessage());
				return "pages/URNConfirm";
			}
		}
		else
		{
			model.addAttribute("errMsg",
					"Urn code doesn't match");
			return "pages/URNConfirm";
		}
	}
	
	@RequestMapping("ProcessTransaction")
	public String processTransaction(@RequestParam("txtAmount")double transactionamount,@RequestParam("txtPwd") String transactionPwd,HttpSession session,Model model )
	{
		
		
		//String payeeacc=(String)session.getAttribute("payeeAccountNo");
		String payeeaccountnos =(String) session.getAttribute("payeeAccountNo");
		System.out.println("string in "+payeeaccountnos);
		
		Long payeeaccountno = Long.parseLong(payeeaccountnos);
		System.out.println("Long convert"+payeeaccountno);
		
		Long accountno=(Long)session.getAttribute("accountno");
		System.out.println("acc no"+accountno);
//		Long accountno=Long.parseLong(acc);
				//Long.parseLong(acc);
		Users user=null;
		Transactions transaction=null;
		Transactions payeetransaction=null;
		FundTransfer transferInfo=null;
		
		int customerid=(int)userService.getCustomerId(accountno);
		System.out.println("in cid"+customerid);
		AccountMaster accountMaster=null;
		AccountMaster payeeaccountMaster=null;
		System.out.println("customer id:"+customerid);
		//int userid = (int) session.getAttribute("userid");
		int userid=(int)session.getAttribute("userid");
		//int userid=Integer.parseInt(id);
		System.out.println("userid"+userid);
		
		user=userService.getUser(userid);
		AccountMaster account=userService.getAccount(accountno);
		System.out.println("inasgvh:"+account);
		System.out.println(user);
		System.out.println(transactionPwd+"="+user.getTransPassword());
		if(transactionPwd.equalsIgnoreCase(user.getTransPassword()))
		{
			System.out.println("password valid");
			System.out.println("acc"+account.getAccountBalance());
			if(account.getAccountBalance()>transactionamount)
			{
				
				
				try{
				System.out.println("in transaction success");
				Double balance=account.getAccountBalance();
				Double updatedBalance=balance-transactionamount;
				System.out.println();
				payeeaccountMaster=userService.getAccount(payeeaccountno);
				System.out.println("payee acc s"+payeeaccountMaster);
				Double payeebalance=payeeaccountMaster.getAccountBalance();
				Double updatedPayeeBalance=payeebalance+transactionamount;
				
				
				 long millis=System.currentTimeMillis();  
			     java.sql.Date date=new java.sql.Date(millis);  
				 
			     transferInfo=new FundTransfer();
			      transferInfo.setAccount_Id(accountno); 
			      transferInfo.setDateOfTransfer(date);
			      transferInfo.setPayee_Account(payeeaccountno);
			      transferInfo.setTransferAmount(transactionamount);
			      
			      System.out.println(transferInfo);
			      
			      transaction=new Transactions();
			      transaction.setAccountID(accountno);
			      transaction.setDateOfTransaction(date);
			      transaction.setTran_Description("Fund Transfer");
			      transaction.setTransactionAmount(transactionamount);
			      transaction.setTransactionType('D');
				
			      payeetransaction=new Transactions();
			      payeetransaction.setAccountID(payeeaccountno);
			      payeetransaction.setDateOfTransaction(date);
			      payeetransaction.setTran_Description("Fund Transfer");
			      payeetransaction.setTransactionAmount(transactionamount);
			      payeetransaction.setTransactionType('C');
			      
			      
			      System.out.println(transaction);
			      accountMaster=userService.getAccount(accountno);
			      accountMaster.setAccountBalance(updatedBalance);
			      
			      payeeaccountMaster.setAccountBalance(updatedPayeeBalance);
			      
			      System.out.println("ft");
				userService.fundTransfer(transferInfo);
					System.out.println("it");
				userService.insertTransaction(transaction);
				userService.insertTransaction(payeetransaction);
					System.out.println("upd");
				userService.updateBalance(accountMaster);
					System.out.println("success upd payer");
				userService.updateBalance(payeeaccountMaster);
					System.out.println("success upd payee");
					System.out.println("transaction cmpltd");
				
				model.addAttribute("amount", transactionamount);
				model.addAttribute("payeeaccountno", payeeaccountno);
				
					return "pages/FTSuccess";
				}
				
				catch(Exception e)
				{
					model.addAttribute("errMsg",
							"Error occured:"+e.getMessage());
					return "pages/FTPay";	
				}
				
			}
			else
			{
				model.addAttribute("errMsg",
						"Not Sufficient Balance");
				return "pages/FTPay";				}
		}
		else
		{
			model.addAttribute("errMsg",
					"Wrong Transaction Password");
		return "/pages/FTPay";
		}
	}
	
	
		@RequestMapping("trackRequest")
		public String processGetServiceForm(@RequestParam("requestId")int requestid,Model model)
		{
			
			System.out.println(requestid);
			System.out.println("Inside Controller Service Track ");
			ServiceTracker tracker=null;
			try 
			{
				System.out.println("inTry");
				tracker=userService.getRequestedServiceList(requestid);
				System.out.println("Tracker Object:"+tracker);
				model.addAttribute("object",tracker);
				return "pages/ShowServiceTrack";
			
			} 
			catch (Exception e) 
			{
				System.out.println(e.getMessage());
				model.addAttribute("errMsg",
						"Could not retrieve the data. Reason : "+e.getMessage());
				return "pages/ErrorPage";

			}
		}
		
		//================================================
		//			ADMIN LOGIN
		//================================================
		
		@RequestMapping("Adminlogin")
		public String getAdminPage(@RequestParam("username") String username,@RequestParam("password") String pass,Model model)
		{
			if(username.equalsIgnoreCase("admin") && pass.equalsIgnoreCase("admin") )
			 {
				System.out.println("login success");
				 return "adminIndex";
			 }
			else
			{
				System.out.println("Login failed");
				 model.addAttribute("errMsg", "Invalid UserName And Password");
				 return ".././AdminPage";
			}
		}
		

		//=============================================
		//			GET NEW ACCOUNT PAGE
		//=============================================
		@RequestMapping("NewAccount")
		public String getNewAccountPage(Model model)
		{

			List<String> accountType = new ArrayList<String>();
			accountType.add("Select");
			accountType.add("Saving Account");
			accountType.add("Current Account");
			
			model.addAttribute("Type",accountType);
			model.addAttribute("request",new RequestTable());
			return "pages/NewAccount";
		}
	
		//===================================================
		//			ACCOUNT REQUEST
		//==================================================
		@RequestMapping(value="processRegistration",method = RequestMethod.POST)
		public String addAccountRequest(@ModelAttribute("request") @Valid RequestTable reqTab ,BindingResult result ,Model model)
		{	
			int customerID = reqTab.getCustId();
			Customer customer = userService.getCustomerbyId(customerID);
		
			
			if(customer!=null)
			{
				int accId = -1;
				try
				{
					accId = userService.addRequest(reqTab);
					model.addAttribute("AccountID", accId);
					return "pages/SuccessReg";
				} 
				catch (Exception e)
				{
					model.addAttribute("errMsg","Unable To add New Account Creation Request "+ e.getMessage());
					return "pages/NewAccount";
				}
			}
			else
			{
				model.addAttribute("errMsg","Customer Id Doesn't Exist");
				return "pages/NewAccount";
			}
		}
		//======================================================================
		//				VIEW REQUEST IN ADMIN TABLE
		//======================================================================
		
		@RequestMapping("ViewRequest")
		public String getRequestPage(Model model)
		{
			List<RequestTable> requestTab = null;
			try
			{
				requestTab = userService.getAllRequest();
				model.addAttribute("request", requestTab);
			}
			catch (Exception e) 
			{
				model.addAttribute("errMsg","Unable to Retrieve Request .\n Reason :"+e.getMessage());
				return "pages/ViewRequestPage";
			}
			if(requestTab == null)
			{
				model.addAttribute("errMsg","No Request Found");
				return "pages/ViewRequestPage";
			}
			return "pages/ViewRequestPage";
		}
		
		//========================================================================
		//					CREATE NEW ACCOUNT PAGE
		//==========================================================================
		@RequestMapping("CreateAccount")
		public String getCreateAccountPage(@RequestParam("custId")int cust_Id , Model model)
		{
			
			RequestTable req = userService.getAccountId(cust_Id);
			System.out.println(req);
			model.addAttribute("Request", req);
		//	model.addAttribute("customer", customer);
			model.addAttribute("account",new AccountMaster());
		
			return "pages/CreateAccount";
		}
		
		//=========================================================================
		//						ADD ACCOUNT 
		//=========================================================================
		@RequestMapping(value="InsertAccount" , method=RequestMethod.POST)
		public String processToAddAcouct(@ModelAttribute("account")AccountMaster account, Model model)
		{
			try
			{
				System.out.println("adding account");
				userService.addUsers(account);
				int accid= (int) account.getAccountId();
				userService.deleteRequest(accid);
				
				return "pages/sucess";
			} 
			catch (UserException e)
			{
				//System.out.println(e.getMessage());
				model.addAttribute("errMsg",e.getMessage());
				return "pages/CreateAccount";
			}
			
		
		}
		
		//=============================================================================
		//						VIEW SERVICE REQUEST
		//=============================================================================
		
		@RequestMapping("ViewService")
		public String getServiceRequest(Model model)
		{
			List<ServiceTracker> service = null;
			try 
			{
				service = userService.getAllService();
				model.addAttribute("Service", service);
			} 
			catch (UserException e) 
			{
				model.addAttribute("errMsg","Unable to Retrieve Service Request .\n Reason :"+e.getMessage());
				return "pages/ViewServicePage";
			}
			if(service == null)
			{
				model.addAttribute("errMsg","No Records Found");
				return "pages/ViewServicePage";
			}
			return "pages/ViewServicePage";
		}
		
		//===============================================
		//			Update Request Status
		//=================================================
		
		@RequestMapping("UpdateRequest")
		public String processUpdate(@RequestParam("serviceId") int serviceId,Model model)
		{
			ServiceTracker service= null;
			service = userService.getService(serviceId);
			String getstatus = service.getService_Status();
			System.out.println(getstatus);
			
			//update
			
			service.setService_Status("Cleared");
			userService.updateServiceStatus(service);
			model.addAttribute("Success","Service Request Cleared");
			return "pages/UpdateSuccess";
		}
		
		//=========================================================================
		//				ADMIN TRANSACTION
		//=========================================================================
			
		@RequestMapping("Daily")
		public String processDailyTransaction(@RequestParam("date") Date date,Model model)
		{
			List<Transactions> dtlist=new ArrayList<Transactions>();
			try
			{
				dtlist=userService.viewDailyReport(date);
				model.addAttribute("DTlist",dtlist);
				return "pages/DailyTransactions";
			}
			catch(UserException e)
			{
				model.addAttribute("errMsg","No record Found :"+e.getMessage());
				return "pages/DailyTransactions";
			}
			
			
		}
		
		
		@RequestMapping(value="Monthly",method=RequestMethod.POST)
		public String processMonthly(@RequestParam("sdate") Date StartDate,@RequestParam("edate") Date EndDate,Model model)
		{
			List<Transactions> mtlist=null;
			try
			{
				mtlist=new ArrayList<>();
				mtlist=userService.viewMonthlyReport(StartDate, EndDate);
				model.addAttribute("MTlist",mtlist);
			}
			catch(UserException e)
			{
				model.addAttribute("errMsg","No record Found :"+e.getMessage());
				return "pages/MonthlyTransactions";
			}
			return "pages/MonthlyTransactions";
		}
		
		
		@RequestMapping("Yearly")
		public String processYearly(@RequestParam("sdate") Date StartDate,@RequestParam("edate") Date EndDate,Model model)
		{
			List<Transactions>ytlist=null;
			try
			{
				ytlist=userService.viewYearlyReport(StartDate, EndDate);
				model.addAttribute("YTlist",ytlist);
			}
			catch(UserException e)
			{
				model.addAttribute("errMsg","No record Found :"+e.getMessage());
				return "pages/YearlyTransactions";
			}
			return "pages/YearlyTransactions";
		}
		
		@RequestMapping("ShowAccountDetails")
		public String showAccountDetails(Model model,HttpSession session)
		{
			Long accountno = (Long) session.getAttribute("accountno");
			AccountMaster account = userService.getAccount(accountno);
		//	double balance = account.getAccountBalance();
			model.addAttribute("account", account);
			return "pages/AccountSummary";
		}
		
	}
	
	
	


	

