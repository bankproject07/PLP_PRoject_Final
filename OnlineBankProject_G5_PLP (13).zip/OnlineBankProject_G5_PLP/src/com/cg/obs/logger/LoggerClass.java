package com.cg.obs.logger;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.apache.log4j.WriterAppender;

public class LoggerClass

{

public static Logger myLogger = Logger.getLogger(Logger.class);

static WriterAppender appender = null ;

static SimpleLayout layout = new SimpleLayout();

static

{

try

{

FileOutputStream fout = new FileOutputStream("D:/log.txt") ;

appender = new WriterAppender(layout,fout) ;

}

catch(FileNotFoundException e)

{

e.printStackTrace();

}

myLogger.addAppender(appender);

}

}