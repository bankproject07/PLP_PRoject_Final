package com.cg.obs.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.exception.UserException;

@Repository("adminDao")
public class AdminDaoImpl implements IAdminDao
{

	@PersistenceContext
	private EntityManager manager;
	
	
	public AdminDaoImpl()
	{
		
	}


	public AdminDaoImpl(EntityManager manager)
	{
	
		this.manager = manager;
	}

	public EntityManager getManager()
	{
		return manager;
	}


	public void setManager(EntityManager manager)
	{
		this.manager = manager;
	}



	@Override
	public void deleteRequest(int accountId) throws UserException 
	{
		try 
		{
			RequestTable request = manager.find(RequestTable.class, accountId);
			manager.remove(request);
		}
		catch (Exception e) 
		{
			throw new UserException(e.getMessage());
		}
		
	}

	@Override
	public ServiceTracker getService(int serviceId) throws UserException
	{
		ServiceTracker service = null;
		try
		{
			service = new ServiceTracker();
			service = manager.find(ServiceTracker.class, serviceId);
			System.out.println(service);
			
		} 
		catch (Exception e)
		{
			throw new UserException(e.getMessage());
		}
		if(service == null)
		{
			throw new UserException("No Service found");
		}
		return service;
	}
	
	

	@Override
	public void updateServiceStatus(ServiceTracker service)
			throws UserException
	{
		try 
		{
			manager.merge(service);
			manager.flush();
		} 
		catch (Exception e)
		{
			throw new UserException(e.getMessage());
		}
		
	}


	@Override
	public Customer getCustomerbyId(int id) throws UserException
	{
		Customer customer=null ;
		try
		{
			customer = new Customer();
			customer  = manager.find(Customer.class,id);
			System.out.println("custId :"+customer);
		} 
		catch (Exception e)
		{
			throw new UserException("Customer ID not Found  " +e.getMessage());
		}
		return customer;
	}
	@Override
	public List<RequestTable> getAllRequest() throws UserException {
		List<RequestTable> request = null;
		try
		{
			TypedQuery<RequestTable> reqQuery = manager.createQuery("select r from RequestTable r",RequestTable.class);
			request = reqQuery.getResultList();
			
		} 
		catch (Exception e)
		{
			throw new UserException(e.getMessage());
		}
		if(request==null || request.isEmpty())
		{
			throw new UserException("No Request Found");
		}
		return request;
	}

	@Override
	public RequestTable getAccountId(int custId) throws UserException {
		
		RequestTable request = null;
		try
		{
			
			request = manager.find(RequestTable.class, custId);
		
			System.out.println(request);
			
		}
		catch (Exception e)
		{
			System.out.println("in catch block");
			e.printStackTrace();
			//throw new UserException("Unable to fetch Request" +e.getMessage());
		}
		if(request == null)
		{
			System.out.println("if null");
			throw new UserException("No Request Found ");
		}
		return request;
	}

	@Override
	public void addUsers(AccountMaster accountMaster) throws UserException {
		//AccountMaster acc = new AccountMaster();
		try 
		{
			System.out.println("  in dao add  "+accountMaster);
			manager.persist(accountMaster);
			
		} 
		catch (Exception e) {
			e.printStackTrace();
			//throw new UserException("Unable to add Account " + e.getMessage());
		}
	
	}
	

	@Override
	public List<ServiceTracker> getAllService() throws UserException 
	{
		List<ServiceTracker> service  = null;
		try
		{
			TypedQuery<ServiceTracker> serviceQuery = manager.createQuery("select s from ServiceTracker s",ServiceTracker.class);
			service = serviceQuery.getResultList();
			
		}
		catch (Exception e) 
		{
			throw new UserException(e.getMessage());
		}
		
		return service;
	}
	
	//TRANSACTIONS..

	@Override
	public List<Transactions> viewDailyReport(Date StartDate)throws UserException
	{
		List<Transactions> transaction=new ArrayList<>();
		try
		{
			String str="select t from Transactions t where t.dateOfTransaction=:StartDate";
			TypedQuery<Transactions>query=manager.createQuery(str,Transactions.class);
			query.setParameter("StartDate",StartDate);
			transaction=query.getResultList();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return transaction;
		
		}

	@Override
	public List<Transactions> viewMonthlyReport(Date StartDate, Date EndDate)
			throws UserException 
			{
		
		
		List<Transactions> tlist=new  ArrayList<Transactions>();
		try {
			
			String str="select t from Transactions t where t.dateOfTransaction between:StartDate and :EndDate";
			TypedQuery<Transactions>query=manager.createQuery(str,Transactions.class);
			query.setParameter("StartDate",StartDate);
			query.setParameter("EndDate",EndDate);	
			tlist = query.getResultList();
			
		} 
		catch (UserException e) 
		{
			throw new UserException("no data found:"+e.getMessage());
		}
		return tlist;
	}

	@Override
	public List<Transactions> viewYearlyReport(Date StartDate, Date EndDate)
			throws UserException
	{
		List<Transactions> tlist= new ArrayList<Transactions>();
		try {
			String str="select t from Transactions t where t.dateOfTransaction between :StartDate and :EndDate";
			TypedQuery<Transactions>query=manager.createQuery(str,Transactions.class);
			query.setParameter("StartDate",StartDate);
			query.setParameter("EndDate",EndDate);
			tlist = query.getResultList();
		} 
		catch (UserException e) 
		{
			throw new UserException("no data found:"+e.getMessage());
		}
		return tlist;
	}


}





















